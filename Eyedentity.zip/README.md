# attendance-tracker
YRHacks 2023 project

send to backend:
- image associated with a person
- image to do attendance with

receive from backend:
- json containing which people are in the image and their position
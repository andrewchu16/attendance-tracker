# Attendance Tracker Frontend

## Setup
1. Go to the 'frontend' folder.
2. Run `npm install`

## Run Developer Mode
```bash
npm run dev
```

## Build (and run)
This will build the project for deployment.

1. Run `npm run build`
2. Run `npm run preview`